import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ValasztasComponent } from './valasztas/valasztas.component';

const routes: Routes = [
  {path: "valasztas", component: ValasztasComponent},
  {path: "", component: ValasztasComponent},
  {path: "**", component: ValasztasComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
