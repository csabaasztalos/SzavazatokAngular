import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ValasztasComponent } from './valasztas.component';

describe('ValasztasComponent', () => {
  let component: ValasztasComponent;
  let fixture: ComponentFixture<ValasztasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ValasztasComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ValasztasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
